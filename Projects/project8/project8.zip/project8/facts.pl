commission('Mary', 'Smith', 300, 19000, 0.1).
commission('Floyd', 'Jenkins', 500, 3000, 0.12).
commission('Rose', 'Harvey', 500, 20000, 0.15).
hourly('Maria', 'Garcia', 20, 8.5).
hourly('Carlton', 'West', 42, 12.5).
hourly('Viola', 'Jennings', 60, 17.5).
salaried('Jeremy', 'Greer', 170).
salaried('Jane', 'Brown', 5000).
salaried('George', 'Miller', 1900).
salaried('Robert', 'Johnson', 3000).